import subprocess
from openai import OpenAI

client = OpenAI(api_key="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")
from time import sleep


# Command to run the Java program
java_program = ['java', 'Game']  # Make sure ProgramB is compiled and in the current directory

conversation_history = ""

# Start the Java program as a subprocess
process = subprocess.Popen(java_program, 
                           stdin=subprocess.PIPE,  # To send input
                           stdout=subprocess.PIPE,  # To capture output
                           stderr=subprocess.PIPE,  # To capture errors (if any)
                           text=True)              # Use text mode to send/receive strings

# Function to read output from the Java program
def read_output():
    while True:

        if output == '' and process.poll() is not None:
            break
        if output:
            return output.strip()

# Function to send the Java program's output to ChatGPT
def get_gpt_response(prompt):
    global conversation_history
    conversation_history += prompt + "\n"
    completion = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": "You are playing an old school style text game. You need to take on the role of the player and provide short one or two word responses without any punctuation, based on the user prompts. The basic commands in the game are look, move, get and open with other nouns."},
            {
                "role": "user",
                "content": conversation_history
            }
        ]
    )
    conversation_history += completion.choices[0].message.content +"\n"
    return completion.choices[0].message.content
    
    

# Run a loop to send multiple inputs to the Java program
try:
    while True:
        output = process.stdout.readline()
        print("GAME OUTPUT: " + output)
        # Get user input
        user_input = get_gpt_response(output)
        print("GPT INPUT: "  + str(user_input))

        # Send the input to the Java program
        process.stdin.write(str(user_input) + "\n")
        process.stdin.flush()  # Ensure the input is sent

        # Read the output from the Java program

        sleep(1)
        # Exit loop if user input is -1
        if user_input == "-1":
            break

except KeyboardInterrupt:
    print("Process interrupted.")

# Ensure the Java process is terminated properly
process.stdin.close()
process.stdout.close()
process.stderr.close()
process.wait()
