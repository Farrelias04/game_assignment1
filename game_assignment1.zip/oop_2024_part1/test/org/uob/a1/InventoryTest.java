package org.uob.a1;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.TestMethodOrder;

public class InventoryTest {
   
    
    @Test
    public void testConstructor() {
        Inventory inventory = new Inventory();
        int mark = 0;
        mark += ("".equals(inventory.displayInventory())) ? 3 : 0;
        System.out.println("AUTOMARK::Inventory.testConstructor: " + mark);
    }

    @Test
    public void testAddItem() {
        Inventory inventory = new Inventory();
        inventory.addItem("bow");
        int mark = 0;
        mark += (inventory.hasItem("bow") > -1) ? 3 : 0;
        System.out.println("AUTOMARK::Inventory.testAddItem: " + mark);
    }

    @Test
    public void testHasItem() {
        Inventory inventory = new Inventory();
        inventory.addItem("bow");
        int mark = 0;
        mark += (inventory.hasItem("bow") > -1) ? 3 : 0;
        System.out.println("AUTOMARK::Inventory.testHasItem: " + mark);
    }

    @Test
    public void testRemoveItem() {
        Inventory inventory = new Inventory();
        inventory.addItem("bow");
        inventory.addItem("spear");
        inventory.removeItem("bow");
        int mark = 0;
        mark += (inventory.hasItem("bow") == -1) ? 3 : 0;
        System.out.println("AUTOMARK::Inventory.testRemoveItem: " + mark);
    }

    @Test
    public void testDisplayInventory() {
        Inventory inventory = new Inventory();
        inventory.addItem("sword");
        inventory.addItem("bow");
        int mark = 0;
        mark += ("sword bow ".equals(inventory.displayInventory())) ? 3 : 0;
        System.out.println("AUTOMARK::Inventory.testDisplayInventory: " + mark);
    }

   

}